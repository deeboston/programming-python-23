/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    static Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private final String url = "jdbc:mysql://localhost:3305/connectiondb"; // Change to your database name
    private final String user = "root"; // Change if necessary
    private final String password = ""; // Change if necessary
    private final String driver = "com.mysql.cj.jdbc.Driver";
    private Connection cx;

    public Connection connect() {
        try {
            Class.forName(driver);
            cx = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
        return cx;
    }

    public void disconnect() {
        if (cx != null) {
            try {
                cx.close();
            } catch (SQLException e) {
                System.out.println("Failed to close connection: " + e.getMessage());
            }
        }
    }
}
