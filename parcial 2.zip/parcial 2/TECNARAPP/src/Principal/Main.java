/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Principal;

import Clases.DatabaseConnection;
import Ventanas.FrmClientes;
import Ventanas.FrmLogin;

/**
 *
 * @author Ing. Narvaez Mejia
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrmLogin app = new FrmLogin();
        app.setVisible(true);
        
        new FrmClientes();
    }
    
}
