/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ventanas;

import Clases.DatabaseConnection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.DecimalFormat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class FrmVentas extends javax.swing.JFrame {
    
    private DatabaseConnection dbConnection;
    private DefaultTableModel dtm;
    private Object[] Ventas = new Object[6];
    private int filaSeleccionada;
    
    
public FrmVentas() {
    initComponents();
    dbConnection = new DatabaseConnection(); // Initialize dbConnection first
    dtm = (DefaultTableModel) tblTableVentas.getModel();
    loadProductos(); // Load existing users after dbConnection is initialized
}
    
public void addProductos() {
    String Cliente = txtCliente.getText();
    String Producto = txtProducto.getText();
    String Precio = txtPrecio.getText();
    String Fecha = txtFecha.getText();
    String Cantidad = txtCantidad.getText();
    String Total = lblTotal.getText();
    

    try (Connection connection = dbConnection.connect()) {
        String sql = "INSERT INTO productos (Cliente, Producto, Precio, Fecha, Cantidad, Total) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, Cliente);
        statement.setString(2, Producto);
        statement.setString(3, Precio);
        statement.setString(4, Fecha);
        statement.setString(5, Cantidad);
        statement.setString(6, Total);
        statement.executeUpdate();
        JOptionPane.showMessageDialog(null, "Producto agregado exitosamente!");
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al agregar producto: " + ex.getMessage());
        System.out.println("Error en addProductos: " + ex.getMessage()); // Para depuración
    }
}



    public void loadProductos() {
    try (Connection connection = dbConnection.connect()) {
        String sql = "SELECT * FROM productos";
        PreparedStatement statement = connection.prepareStatement(sql);
        java.sql.ResultSet resultSet = statement.executeQuery();

        // Limpiar la tabla antes de agregar nuevos datos
        dtm.setRowCount(0);

        // Recorrer los resultados y agregarlos a la tabla
                    while (resultSet.next()) {
                Object[] fila = new Object[6]; // Number of columns in your MySQL table
                fila[0] = resultSet.getString("Cliente"); // Change to the column names
                fila[1] = resultSet.getString("Producto");
                fila[2] = resultSet.getString("Precio");
                fila[3] = resultSet.getString("Fecha");
                fila[4] = resultSet.getString("Cantidad");
                fila[5] = resultSet.getString("Total");
                dtm.addRow(fila);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + ex.getMessage());
        }
    }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCliente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtProducto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        lblIVA = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTableVentas = new javax.swing.JTable();
        btnGuardarVentas = new javax.swing.JButton();
        btnCargarVentas = new javax.swing.JButton();
        btnModificarVentas = new javax.swing.JButton();
        btnEliminarVentas = new javax.swing.JButton();
        btnCalcularIVA = new javax.swing.JButton();
        lblTotal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("VENTAS");

        jLabel2.setText("CLIENTE:");

        jLabel3.setText("PRODUCTO:");

        jLabel4.setText("PRECIO:");

        jLabel5.setText("FECHA:");

        jLabel6.setText("CANTIDAD:");

        lblIVA.setText("IVA");

        tblTableVentas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "CLIENTE", "PRODUCTO", "PRECIO", "FECHA", "CANTIDAD", "TOTAL"
            }
        ));
        jScrollPane1.setViewportView(tblTableVentas);

        btnGuardarVentas.setText("GUARDAR");
        btnGuardarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarVentasActionPerformed(evt);
            }
        });

        btnCargarVentas.setText("CARGAR");
        btnCargarVentas.setEnabled(false);
        btnCargarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCargarVentasActionPerformed(evt);
            }
        });

        btnModificarVentas.setText("MODIFICAR");
        btnModificarVentas.setEnabled(false);
        btnModificarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarVentasActionPerformed(evt);
            }
        });

        btnEliminarVentas.setText("ELIMINAR");
        btnEliminarVentas.setEnabled(false);
        btnEliminarVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarVentasActionPerformed(evt);
            }
        });

        btnCalcularIVA.setText("CALCULAR");
        btnCalcularIVA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularIVAActionPerformed(evt);
            }
        });

        lblTotal.setText("TOTAL");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(342, 342, 342)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnCalcularIVA)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 683, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel2)
                                        .addComponent(jLabel4)
                                        .addComponent(jLabel6))
                                    .addGap(31, 31, 31)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtCliente)
                                        .addComponent(txtPrecio)
                                        .addComponent(txtCantidad, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE))
                                    .addGap(76, 76, 76)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel3)
                                                .addComponent(jLabel5))
                                            .addGap(44, 44, 44)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(txtProducto)
                                                .addComponent(txtFecha, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)))
                                        .addComponent(lblIVA)
                                        .addComponent(lblTotal)))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(btnGuardarVentas)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnCargarVentas)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnModificarVentas)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnEliminarVentas))))))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIVA)
                    .addComponent(btnCalcularIVA))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTotal)
                .addGap(21, 21, 21)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardarVentas)
                    .addComponent(btnCargarVentas)
                    .addComponent(btnModificarVentas)
                    .addComponent(btnEliminarVentas))
                .addContainerGap(101, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarVentasActionPerformed
        Ventas[0] = txtCliente.getText();
        Ventas[1] = txtProducto.getText();
        Ventas[2] = txtPrecio.getText();
        Ventas[3] = txtFecha.getText();
        Ventas[4] = txtCantidad.getText();
        Ventas[5] = lblTotal.getText();
        
        dtm.addRow(Ventas);
        

        txtCliente.requestFocus();
        
        btnCargarVentas.setEnabled(true);
        btnEliminarVentas.setEnabled(true);
        
        addProductos();
        loadProductos();
        
        System.out.println("Cliente: " + txtCliente.getText());
        System.out.println("Productos: " + txtProducto.getText());
        System.out.println("Precio: " + txtPrecio.getText());
        System.out.println("Fecha: " + txtFecha.getText());
        System.out.println("Cantidad: " + txtCantidad.getText());
        System.out.println("Total: " + lblTotal.getText());
        
    }//GEN-LAST:event_btnGuardarVentasActionPerformed

    private void btnCalcularIVAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularIVAActionPerformed
        try {
            DecimalFormat df = new DecimalFormat("#,##0.00");
            
            double precio = Double.parseDouble(txtPrecio.getText());
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double iva = precio * 0.19;
            double total = ((precio + iva) * cantidad);
            lblIVA.setText("Total IVA: " + df.format(iva));
            lblTotal.setText("Total: " + df.format(total));
        } catch (NumberFormatException ex) {
            lblIVA.setText("Entrada inválida");
            lblTotal.setText("");
        }
    }//GEN-LAST:event_btnCalcularIVAActionPerformed

    private void btnCargarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarVentasActionPerformed
        if(tblTableVentas.getSelectedRow()==-1) {
            JOptionPane.showMessageDialog(null, "No ha seleccionado registro en la tabla", "ERROR AL MODIFICAR REGISTRO", JOptionPane.WARNING_MESSAGE);
        }else{
        filaSeleccionada = tblTableVentas.getSelectedRow();
        txtCliente.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 0).toString());
        txtProducto.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 1).toString());
        txtPrecio.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 2).toString());
        txtFecha.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 3).toString());
        txtCantidad.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 4).toString());
        lblTotal.setText(dtm.getValueAt(tblTableVentas.getSelectedRow(), 5).toString());
        txtCliente.requestFocus();
        
        btnGuardarVentas.setEnabled(false);
        btnCargarVentas.setEnabled(false);
        btnEliminarVentas.setEnabled(false);
        btnModificarVentas.setEnabled(true);
        }
    }//GEN-LAST:event_btnCargarVentasActionPerformed

    private void btnModificarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarVentasActionPerformed
        dtm.setValueAt(txtCliente.getText().trim(), filaSeleccionada, 0);
        dtm.setValueAt(txtProducto.getText().trim(), filaSeleccionada, 1);
        dtm.setValueAt(txtPrecio.getText().trim(), filaSeleccionada, 2);
        dtm.setValueAt(txtFecha.getText().trim(), filaSeleccionada, 3);
        dtm.setValueAt(txtCantidad.getText().trim(), filaSeleccionada, 4);
        dtm.setValueAt(lblTotal.getText().trim(), filaSeleccionada, 5);
        
        txtCliente.setText("");
        txtProducto.setText("");
        txtPrecio.setText("");
        txtFecha.setText("");
        txtCantidad.setText("");
        txtCliente.requestFocus();
        
        btnGuardarVentas.setEnabled(true);
        btnCargarVentas.setEnabled(true);
        btnEliminarVentas.setEnabled(true);
        btnModificarVentas.setEnabled(false);
    }//GEN-LAST:event_btnModificarVentasActionPerformed

    private void btnEliminarVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarVentasActionPerformed
        if(tblTableVentas.getSelectedRow()==-1) {
            JOptionPane.showMessageDialog(null, "No ha seleccionado registro en la tabla", "ERROR ELIMINAR REGISTRO", JOptionPane.ERROR_MESSAGE);
            
        }else{
            JOptionPane.showConfirmDialog(null, "Desea eliminar este registro ?", "CONFIRMACIÓN DE ELIMINACIÓN", JOptionPane.YES_NO_OPTION);
            dtm.removeRow(tblTableVentas.getSelectedRow());
        }
    }//GEN-LAST:event_btnEliminarVentasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcularIVA;
    private javax.swing.JButton btnCargarVentas;
    private javax.swing.JButton btnEliminarVentas;
    private javax.swing.JButton btnGuardarVentas;
    private javax.swing.JButton btnModificarVentas;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblIVA;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JTable tblTableVentas;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtProducto;
    // End of variables declaration//GEN-END:variables

    private Object DecimalFormat(double text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void DatabaseConnection(String Cliente, String Producto, double Precio, String Fecha, int Cantidad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
